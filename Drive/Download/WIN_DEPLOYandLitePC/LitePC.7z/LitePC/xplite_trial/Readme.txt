-------------------------------------------------------------
XPlite 2000lite Professional
(c) LitePC Technologies Pty Ltd 1999-2012.
http://www.litepc.com
-------------------------------------------------------------

Quick Start
===========

Thank you for trying our XPlite free trial!  The XPlite trial will also 
work on Windows 2000!  That�s right - one program for BOTH operating systems.  We currently distribute both an XPlite and 2000lite program as there are some advanced features coming in a future version that require we split them.

XPlite/2000lite Professional is entirely self-contained. There is no bulky 
installation program and no un-installation program. They are not needed. Just 
place the program where YOU want it.  

1) Copy XPlite_TRIAL.exe to your Windows XP/2000 desktop (or any location you 
prefer)
2) Double click on the program icon to start.
3) Add and Remove Windows Components

Yes it really is that easy!


Introduction
=============

**  Windows the way YOU want it!  **

XPlite and 2000lite Professional give YOU the power to set up YOUR machine the 
way YOU want! The power to remove unwanted features, the power to remove 
upgrades that go bad, the power to strip potential security and privacy threats 
out by the roots.

XPlite\2000lite is a world class configuration utility that enhances Windows by 
creating many modular operating system components that you can choose to 
install or remove from your system.  Pick and choose which features YOU need or 
YOU want!  More than a powerful configuration utility - 2000lite gives you 
amazing control to repair Windows as well.  If a particular technology gives 
you trouble you can completely remove it, and then reinstall it as cleanly as 
the day Windows was first installed on your computer.

The ultimate security system?  There can be little argument that certain 
Microsoft technologies have proven themselves to put your privacy, security and 
system stability at risk.  The sheer number of Windows Update security fixes 
that are released on an almost daily basis testify to this fact.  You can 
choose alternate technologies to avoid the security risks, yet the flawed 
components remain on your system unused, until the next irresponsible hacker or 
malicious script takes advantage of the situation.  Everybody should be running 
with the latest patches and Service Packs - but is this enough?  2000lite 
allows you to completely remove features that might put you at risk.  For 
example - many email viruses use Outlook Express and the Windows Address Book 
to invade your privacy and that of your associates whose addresses you have 
stored.  If you choose to use an alternate email system then XPlite\2000lite 
allows you to totally remove Outlook Express and the Windows Address Book from 
your system.  Now you *know* you are protected once and for all!

Modular by design! - What comes out� goes back in!
What if you change your mind and want to reinstall one of the system components 
that you previously uninstalled? No problem! Each uninstaller is coupled with 
an equally powerful installer so you can recover uninstalled components. It is 
as easy as ticking a check box.

Safety!
======
XPlite is 100% compatible with Windwos XP System Restore.  You can remove
EVERY basic feature in XPlite and still have the full protection of System
Restore provided   you have allowed enough disk space for the changes to be
stored (The disk space setting is adjustable under the My Computer properties
System Restore tab.  If you find something amiss just restore to an earlier
time.  XPlite will set a restore point before making any changes to your system
and it will warn you first if the restore point can not be set.

Source Files
============
When installing optional components, XP\2000lite intelligently knows which 
files have been updated by Microsoft Service packs.  Your Operating system will 
have a cache of Service Pack installation files occupying a considerable amount 
of space in your Windows folder.  If you remove these you will need to have a 
local source of service pack files available for your operating system.  If you 
purchased 2000lite on CDROM then we have included the most recent Service Pack 
(at the time of purchase) on the CDROM.  You can also download the full network 
installation from Microsoft (Windows 2000 SP4 is over 100MB).  Use the 
XP\2000lite Preferences Dialog to set the correct path to your Service Pack 
source files.  You should *NOT* simply point the Service Pack Source path to 
your regular Windows 2000 CDROM as this may result in downgrading of system 
files on your computer and potentially the re-introduction of bugs that were 
fixed by Microsoft in the Service Packs.

If you find the setup engine is asking you for the locations of your setup 
files then you should set the location in the preferences tab.  The ideal 
source for filesof the same Service Pack level as your current installation is 
a single "Slipstreamed" CDROM that is of the same level so that you do not have 
to juggle CDROMs between the original version, and the Service Pack files.  
Simply point both paths to the single slipstreamed CDROM that has the 
appropriate file versions on it.


Features
========
XPlite gives you full command over the Windows File Protection (WFP) feature.  
Windows File Protection is a powerful Windows feature that prevents system 
files from being overwritten by poorly designed application and driver 
installers.  However the side effect is that users are prevented from 
controlling their own systems.  XPlite has been specifically engineered to work 
with the WFP feature so that changes to the system are monitored and 
continually protected afterwards.

XPlite must disable WFP in order to customize the operating system, but after 
the system is set up the way you want WFP is re-enabled and you continue with a 
protected operating system.!

You can read more about Windows File Protection on Microsoft's web site:
http://msdn.microsoft.com/library/en-us/wfp/setup/about_windows_file_protection.
asp
http://support.microsoft.com/default.aspx?scid=kb;222193

Advanced Features
=================
XPlite\2000lite is an extremely powerful application that has the caperbility 
to remove core system files, services and deeply rooted registry trees.  We 
have grouped some of the more "serious" components into an Advanced Features 
section of the Add\Remove options tree.  To enable the advanced features check 
the checkbox in the user preference tab.  Be very careful.  While you will not 
crash your machine, you may loose a function that you didnt know you needed if 
you remove many of the advanced features.  For example it is possible to 
eliminate all microsoft networking and you will no longer be able to share 
files between machines on a Microsoft network.  If in doubt - leave the 
advanced features installed. It is an easy process to re-install features if 
you think you removed something you need.  Just tick the box  and let XPlite 
re-install the feature as if it was installed for the first time.

The Future
==========
As a licensed XPlite Professional customer you have access to our latest beta 
files for the next version also.  We will be adding a lot more features to the 
add\remove list as well as some other very nice utilities that will scan the 
driver files and weed out some redundancy.

Your license
============
You must not redistribute LitePC Technologies software to anyone or allow 
anyone else to access your secure download area using your license information.

Licenses, passwords or Activation Keys found "circulating" on the internet will 
result in your License being revoked immediately and your download access 
removed from the servers.  Each License and Activation Key is unique for each 
user.  It is your responsibility to keep this information private.  If your 
license "gets out" it is your fault and you will forfeit your access for future 
downloads and upgrades.  Please keep your license secure.

Our computer programs are protected by copyright law and international 
treaties.  Unauthorized reproduction or distribution of all or parts of our 
programs may result in prosecution.

Please don�t forget this is your private copy for your personal use only. If 
you require a site license or want to use our technology to distribute 
pre-configured systems then you need to obtain the appropriate license from 
http://www.litepc.com


Your Login
http://www.litepc.com/login.html

Support:
http://www.litepc.com/support.html

LitePC Technologies Pty Ltd
Windows YOUR way!

Phone (Australia):  +61-3-9876-7792
http://www.litepc.com       http://www.embeddingwindows.com



-------------------------------------------------------------
